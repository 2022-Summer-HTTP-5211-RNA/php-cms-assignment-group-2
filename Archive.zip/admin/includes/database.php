<?php

/*$connect = mysqli_connect(
    "localhost",
    "root",
    "",
    "php-cms"
);*/

$connect = mysqli_connect(
    "localhost",
    "root",
    "",
    "php-cms"
);

mysqli_set_charset( $connect, 'UTF8' );
